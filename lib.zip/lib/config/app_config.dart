// lib/config/app_config.dart
// ⚠️  THIS FILE IS GITIGNORED — NEVER COMMIT THIS FILE
// ⚠️  Contains real API credentials for AgricAssist ZW
// Developed by Sir Enocks — Cor Technologies

class AppConfig {
  // ── Paynow Zimbabwe Credentials ───────────────────────
  // Company: Sir Enocks Cor Technologies
  // Type: 3rd Party Integration
  // Payment Link: Farm Supervisor
  static const String paynowIntegrationId  = '23678';
  static const String paynowIntegrationKey = '8312afc0-271d-4e13-bce2-077ea58f31ee';

  // ── Paynow URLs ───────────────────────────────────────
  // resultUrl: Paynow POSTs payment result here (needs live server later)
  // returnUrl: User is redirected here after payment (needs live server later)
  // For now these are placeholders — polling handles confirmation instead
  static const String paynowResultUrl = 'https://agricassist.co.zw/payment/result';
  static const String paynowReturnUrl = 'https://agricassist.co.zw/payment/return';

  // ── Claude API Key ────────────────────────────────────
  static const String claudeApiKey = 'YOUR_CLAUDE_API_KEY_HERE';

  // ── Subscription Price ────────────────────────────────
  static const double subscriptionAmountUSD = 2.99;

  // ── App Environment ───────────────────────────────────
  // Set to true when you have a live server and real resultUrl
  static const bool isProduction = false;

  // ── Admin Phone Number ────────────────────────────────
  // This phone number gets admin role automatically (fallback if DB role not set)
  // Change this to your actual phone number before release
  static const String adminPhoneNumber = '0775911815';
}